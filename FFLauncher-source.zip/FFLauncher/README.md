# FF Launcher

Launcher Android em Kotlin + Jetpack Compose para abrir o pacote `com.dts.freefireth`.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK Platform 35
- Gradle wrapper gerado pelo Android Studio

## Compilar
1. Abra a pasta `FFLauncher` no Android Studio.
2. Aguarde a sincronização Gradle.
3. Selecione Build > Build APK(s).
4. O APK debug ficará normalmente em `app/build/outputs/apk/debug/app-debug.apk`.

## Notas
- O package do launcher é `com.kratos.fflauncher`, diferente do pacote do jogo.
- `com.dts.freefireth` é declarado em `<queries>` para permitir a consulta no Android 11+.
- A versão instalada é consultada em tempo de execução; não é assumido que seja 1.132.1.
- O lançamento automático pode ser limitado pelas regras de atividade em segundo plano do Android.
- Esta app não lê nem modifica o processo do jogo.
