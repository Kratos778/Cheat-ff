package com.kratos.fflauncher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val TARGET_PACKAGE = "com.dts.freefireth"
private const val TARGET_VERSION = "1.132.1"

data class GameStatus(
    val installed: Boolean,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val message: String
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val darkColors = darkColorScheme(
                primary = Color(0xFF58E6C5),
                secondary = Color(0xFF83A9FF),
                background = Color(0xFF080D16),
                surface = Color(0xFF111A29),
                onPrimary = Color(0xFF05130F),
                onBackground = Color(0xFFEAF1FF),
                onSurface = Color(0xFFEAF1FF)
            )

            MaterialTheme(colorScheme = darkColors) {
                var autoLaunch by rememberSaveable { mutableStateOf(true) }
                var status by remember { mutableStateOf(readGameStatus()) }
                var launchMessage by remember { mutableStateOf("Pronto para verificar.") }
                var autoLaunchHandled by rememberSaveable { mutableStateOf(false) }

                LaunchedEffect(Unit) {
                    status = readGameStatus()
                    if (autoLaunch && !autoLaunchHandled && status.installed) {
                        autoLaunchHandled = true
                        launchGame { launchMessage = it }
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LauncherScreen(
                        status = status,
                        launchMessage = launchMessage,
                        autoLaunch = autoLaunch,
                        onAutoLaunchChange = { autoLaunch = it },
                        onRefresh = {
                            status = readGameStatus()
                            launchMessage = "Estado atualizado."
                        },
                        onLaunch = {
                            status = readGameStatus()
                            launchGame { launchMessage = it }
                        },
                        onOpenAppInfo = { openAppInfo() }
                    )
                }
            }
        }
    }

    private fun readGameStatus(): GameStatus {
        return try {
            val info = getPackageInfoCompat(TARGET_PACKAGE)
            val versionName = info.versionName ?: "desconhecida"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toLong()
            }

            GameStatus(
                installed = true,
                versionName = versionName,
                versionCode = versionCode,
                message = if (versionName == TARGET_VERSION) {
                    "Versão de referência encontrada."
                } else {
                    "Jogo instalado; versão diferente ou não confirmada."
                }
            )
        } catch (_: PackageManager.NameNotFoundException) {
            GameStatus(
                installed = false,
                message = "Free Fire não encontrado neste dispositivo."
            )
        } catch (e: Exception) {
            GameStatus(
                installed = false,
                message = "Não foi possível verificar: ${e.message ?: "erro desconhecido"}"
            )
        }
    }

    private fun getPackageInfoCompat(packageName: String): PackageInfo {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getPackageInfo(
                packageName,
                PackageManager.PackageInfoFlags.of(0)
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, 0)
        }
    }

    private fun launchGame(onResult: (String) -> Unit) {
        val launchIntent = packageManager.getLaunchIntentForPackage(TARGET_PACKAGE)
        if (launchIntent == null) {
            onResult("Não foi possível abrir o jogo. Confirma se está instalado e tem um ícone de lançamento.")
            return
        }

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(launchIntent)
            onResult("Pedido de abertura enviado ao Android.")
        } catch (_: ActivityNotFoundException) {
            onResult("O Android não encontrou uma atividade de lançamento para o jogo.")
        } catch (e: Exception) {
            onResult("Falha ao abrir o jogo: ${e.message ?: "erro desconhecido"}")
        }
    }

    private fun openAppInfo() {
        val intent = Intent(
            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$TARGET_PACKAGE")
        )
        try {
            startActivity(intent)
        } catch (_: Exception) {
            // A tela de informações é opcional; não interromper o launcher.
        }
    }
}

@Composable
private fun LauncherScreen(
    status: GameStatus,
    launchMessage: String,
    autoLaunch: Boolean,
    onAutoLaunchChange: (Boolean) -> Unit,
    onRefresh: () -> Unit,
    onLaunch: () -> Unit,
    onOpenAppInfo: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF101E31), Color(0xFF080D16), Color(0xFF080D16))
                )
            )
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(Color(0xFF173D43), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.Icon(
                    imageVector = Icons.Filled.Android,
                    contentDescription = null,
                    tint = Color(0xFF58E6C5),
                    modifier = Modifier.size(30.dp)
                )
            }
            Column(modifier = Modifier.padding(start = 14.dp)) {
                Text(
                    "FF LAUNCHER",
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp
                )
                Text(
                    "ANDROID • GAME STARTER",
                    color = Color(0xFF8EA3BD),
                    fontSize = 11.sp,
                    letterSpacing = 1.4.sp
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111A29)),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("JOGO-ALVO", color = Color(0xFF8EA3BD), fontSize = 12.sp, letterSpacing = 1.4.sp)
                Text("Free Fire", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(
                    TARGET_PACKAGE,
                    color = Color(0xFF9DB0C8),
                    fontSize = 13.sp
                )
                Divider(color = Color(0xFF27364B))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Icon(
                        imageVector = if (status.installed) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                        contentDescription = null,
                        tint = if (status.installed) Color(0xFF58E6C5) else Color(0xFFFFB86B)
                    )
                    Column(modifier = Modifier.padding(start = 10.dp).weight(1f)) {
                        Text(
                            if (status.installed) "INSTALADO" else "NÃO DETETADO",
                            fontWeight = FontWeight.Bold
                        )
                        Text(status.message, color = Color(0xFF9DB0C8), fontSize = 12.sp)
                    }
                }
                if (status.installed) {
                    InfoRow("Versão instalada", status.versionName ?: "Desconhecida")
                    InfoRow("Version code", status.versionCode?.toString() ?: "Desconhecido")
                    InfoRow("Versão pretendida", TARGET_VERSION)
                }

                Button(
                    onClick = onLaunch,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(14.dp),
                    enabled = status.installed
                ) {
                    androidx.compose.material3.Icon(Icons.Filled.OpenInNew, contentDescription = null)
                    Text(
                        "  ABRIR FREE FIRE",
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(
                    onClick = onRefresh,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    androidx.compose.material3.Icon(Icons.Filled.Refresh, contentDescription = null)
                    Text("  Verificar novamente")
                }
                Text(
                    launchMessage,
                    color = Color(0xFF9DB0C8),
                    fontSize = 12.sp
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111A29)),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("COMPORTAMENTO", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Abrir jogo ao iniciar")
                        Text(
                            "Tenta abrir o jogo quando o launcher inicia e o pacote está instalado.",
                            color = Color(0xFF9DB0C8),
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = autoLaunch,
                        onCheckedChange = onAutoLaunchChange
                    )
                }
                Text(
                    "A preferência aplica-se à sessão atual. O Android pode limitar o lançamento automático em alguns contextos.",
                    color = Color(0xFF8095B0),
                    fontSize = 11.sp
                )
                Button(
                    onClick = onOpenAppInfo,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    enabled = status.installed
                ) {
                    Text("Informações da aplicação")
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111A29)),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("DIAGNÓSTICO", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(
                    "Esta versão é um launcher. Não lê a memória do jogo, não altera o Free Fire e não fornece ESP para jogadores reais.",
                    color = Color(0xFF9DB0C8),
                    fontSize = 13.sp
                )
                Text(
                    "Próxima etapa possível: demonstração 3D independente com bonecos artificiais, linhas e deteção de paredes.",
                    color = Color(0xFF58E6C5),
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "FF LAUNCHER • BUILD 1.0.0",
            color = Color(0xFF60758F),
            fontSize = 10.sp,
            letterSpacing = 1.2.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color(0xFF8EA3BD), fontSize = 12.sp)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
